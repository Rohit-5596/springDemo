package com.cg;
import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringBeanConfig {

	@Bean
	public ArrayList<String> getSkills()
	{
		ArrayList<String> skills=new ArrayList<String>();
		
		skills.add("HTML5");
		skills.add("JAVA");
		skills.add("Spring4");
		return skills;
		
	}
}
