package com.cg.ems.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.Employee;
import com.cg.User;

public class TestEmpDemo {

	public static void main(String[] args) {
	
		ApplicationContext ctx=new ClassPathXmlApplicationContext("beans.xml");
		Employee e2=(Employee)ctx.getBean("emp2");//getBean("id"in.xml file)//e1 is a container
		System.out.println("Emp info: "+e2);
		System.out.println("HashCode e1: "+e2.hashCode());
		
		

	}

}
