package com.cg;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class MainClass {

	public static void main(String[] args) {
		
		XmlBeanFactory factory=new XmlBeanFactory(new ClassPathResource("beans.xml"));
		
		Employee emp=factory.getBean(Employee.class);
		//or Employee emp=(Employee)factory.getBean("employee");
		
		/*emp.setName("Rohit");
		emp.setAge(22);
		emp.setLocation("Pune");
		emp.setProjectCode("Pr0215");*/
		
		System.out.println(emp.getName()+" "+emp.getAge()+" "+emp.getLocation()+" "+emp.getProjectCode()+" "+emp.getSalary()+" "+emp.getSkills());
		
		System.out.println(emp.getDept());

	}

}
