package com.cg;


import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("emp2")
public class Employee {

	@Value("Rohit")
	private String name;
	
	@Value("22")
	private int age;
	
	@Value("Pune")
	private String location;
	
	@Value("Pr567")
	private String projectCode;
	
	@Value("30025")
	private double salary;
	
	@Resource(name="getSkills")
	private List<String> skills;//no direct annotation for collection 
	
	@Autowired
	@Qualifier("dept2")
	Department dept;
	private java.sql.Date empDOJ;
	private LocalDate empDOB;
	
	




	public LocalDate getEmpDOB() {
		return empDOB;
	}





	public void setEmpDOB(LocalDate empDOB) {
		this.empDOB = empDOB;
	}





	public Date getEmpDOJ() {
		return empDOJ;
	}





	public void setEmpDOJ(Date empDOJ) {
		this.empDOJ = empDOJ;
	}





	public Employee(String name, int age, String location) {
		super();
		System.out.println("In second constructor");
		this.name = name;
		this.age = age;
		this.location = location;
		skills=new ArrayList<String>();
	}
	
	

	

	public Employee(String name, int age, String location, String projectCode, double salary, List<String> skills,
			Department dept) {
		super();
		this.name = name;
		this.age = age;
		this.location = location;
		this.projectCode = projectCode;
		this.salary = salary;
		this.skills = skills;
		this.dept = dept;
	}

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	public List<String> getSkills() {
		return skills;
	}

	public void setSkills(List<String> skills) {
		this.skills = skills;
	}

	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getProjectCode() {
		return projectCode;
	}
	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}
	
	
	@Override
	public String toString() {
		return "Employee [name=" + name + ", age=" + age + ", location=" + location + ", projectCode=" + projectCode
				+ ", salary=" + salary + ", skills=" + skills + ", dept=" + dept + ", empDOJ=" + empDOJ + ", empDOB="
				+ empDOB + "]";
	}





	public Employee() {
		super();
		skills=new ArrayList<String>();
	}
	
	
}
