package com.cg.ems.ctrl;



import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.ems.dto.Login;
import com.cg.ems.dto.RegisterDto;
import com.cg.ems.service.LoginService;

@Controller
public class LoginController {

	@Autowired
	LoginService logSer;
	
	@RequestMapping(value="/ShowLoginPage")
	public String dispLoginPage(Model model)
	{
		Login lgg=new Login();
		lgg.setUserName("Enter user Id here");
		model.addAttribute("log",lgg);
		return "Login";//Login is view name...now create Login.jsp
		
	}
	
	@RequestMapping(value="/ValidateUser")
	public String validateUser(@ModelAttribute("log")Login lgg,BindingResult result,Model model) {
		
		System.out.println("user entered: "+lgg);
		if(logSer.validateUser(lgg))
		{
			return "Success";
		}
		else
		{
			model.addAttribute("MsgObj", "Please check your Password");
		return "Login";
		}
	}
	
	/**************ShowRegisterPage*****************/
	
	@RequestMapping(value="ShowRegisterPage")
	public String dispRegisterPage(Model model) {
		
		RegisterDto reg=new RegisterDto();
		ArrayList<String> cityList=new ArrayList<String>();
		cityList.add("Pune");
		cityList.add("Mumbai");
		cityList.add("Noida");
		cityList.add("Bangalore");
		model.addAttribute("cityListObj", cityList);
		
		ArrayList<String> skillList=new ArrayList<String>();
		skillList.add("JAVA");
		skillList.add("HTML");
		skillList.add("CSS3");
		skillList.add("Angular");
		model.addAttribute("skillListObj", skillList);
		
		model.addAttribute("regObj", reg);
		return "Register";
		
	}
}
