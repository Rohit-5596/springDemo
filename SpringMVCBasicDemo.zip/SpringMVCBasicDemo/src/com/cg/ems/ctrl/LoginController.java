package com.cg.ems.ctrl;



import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.ems.dto.Login;
import com.cg.ems.dto.RegisterDto;
import com.cg.ems.service.LoginService;
import com.cg.ems.util.MyStringDateUtil;

@Controller
public class LoginController {

	@Autowired
	LoginService logSer;//for validateUser
	
	@RequestMapping(value="/ShowLoginPage")
	public String dispLoginPage(Model model)
	{
		Login lgg=new Login();
		lgg.setUserName("Enter user Id here");
		model.addAttribute("log",lgg);
		return "Login";//Login is view name...now create Login.jsp
		
	}
	
	@RequestMapping(value="/ValidateUser")
	public String validateUser(@ModelAttribute("log") @Valid Login lgg,BindingResult result,Model model) {
		
		if(result.hasFieldErrors())
		{
			return "Login";
		}
		else
		{
		 System.out.println("user entered: "+lgg);
		 if(logSer.validateUser(lgg))
		 {
			return "Success";
		 }
		 else
		 {
			model.addAttribute("MsgObj", "Please check your Password");
		     return "Login";
		 }
		}
	}
	
	/**************ShowRegisterPage*****************/
	
	@RequestMapping(value="/ShowRegisterPage")
	public String dispRegisterPage(Model model) {
		
		RegisterDto reg=new RegisterDto();
		ArrayList<String> cityList=new ArrayList<String>();
		cityList.add("Pune");
		cityList.add("Mumbai");
		cityList.add("Noida");
		cityList.add("Bangalore");
		model.addAttribute("cityListObj", cityList);
		
		ArrayList<String> skillList=new ArrayList<String>();
		skillList.add("JAVA");
		skillList.add("HTML");
		skillList.add("CSS3");
		skillList.add("Angular");
		model.addAttribute("skillListObj", skillList);
		
		model.addAttribute("regObj", reg);
		return "Register";
		
	}
	
	/**************addUserDetails.obj*****************/
	
	@RequestMapping(value="/AddUserDetails")
	public String insertUserDetails(@ModelAttribute("regObj") RegisterDto reg, BindingResult result,Model model )
	{
		Login log=new Login(reg.getUname(),reg.getPwd());
		logSer.addUser(log);
		String str=MyStringDateUtil.fromArrayToCommaSeparatedString(reg.getSkillSet());
		reg.setSkillSetStr(str);
		logSer.addUserDetails(reg);
		ArrayList<RegisterDto> userList=logSer.getAllUserDetails();
		model.addAttribute("UserListObj",userList);
		return "ListAllUser";
		
	}
	
	    /**************DeleteUser****************/
	
	@RequestMapping(value="/DeleteUser")
	public String deleteUserDetails(@RequestParam("uid") String unm,Model model)
	{
		logSer.deleteUser(unm);
		ArrayList<RegisterDto> userList=logSer.getAllUserDetails();
		model.addAttribute("UserListObj",userList);
		return "ListAllUser";
	}
	
/**************ShowUpdatePage****************/
	
	@RequestMapping(value="/ShowUpdatePage")
	public String updateUserDetails(@RequestParam("uid") String unm,Model model)
	{
		logSer.updateUser(unm);
		ArrayList<RegisterDto> userList=logSer.getAllUserDetails();
		model.addAttribute("UserListObj",userList);
		return "ListAllUser";
	}
	
	
	
}
