package com.cg.ems.dto;

import java.util.Arrays;

public class RegisterDto {

	private String uname;
	private String pwd;
	private String confPwd;
	private String firstName;
	private String lastName;
	private String email;
	private String[] skillSet;
	private char gender;
	private String city;
	private String skillSetStr;
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getConfPwd() {
		return confPwd;
	}
	public void setConfPwd(String confPwd) {
		this.confPwd = confPwd;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String[] getSkillSet() {
		return skillSet;
	}
	public void setSkillSet(String[] skillSet) {
		this.skillSet = skillSet;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getSkillSetStr() {
		return skillSetStr;
	}
	public void setSkillSetStr(String skillSetStr) {
		this.skillSetStr = skillSetStr;
	}
	public RegisterDto(String uname, String pwd, String confPwd, String firstName, String lastName, String email,
			String[] skillSet, char gender, String city, String skillSetStr) {
		super();
		this.uname = uname;
		this.pwd = pwd;
		this.confPwd = confPwd;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.skillSet = skillSet;
		this.gender = gender;
		this.city = city;
		this.skillSetStr = skillSetStr;
	}
	public RegisterDto() {
		super();
	}
	@Override
	public String toString() {
		return "RegisterDto [uname=" + uname + ", pwd=" + pwd + ", confPwd=" + confPwd + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", email=" + email + ", skillSet=" + Arrays.toString(skillSet)
				+ ", gender=" + gender + ", city=" + city + ", skillSetStr=" + skillSetStr + "]";
	}
	
	
}
