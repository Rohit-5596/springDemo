package com.cg.ems.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.dao.LoginDao;
import com.cg.ems.dao.LoginDaoImpl;
import com.cg.ems.dto.Login;
import com.cg.ems.dto.RegisterDto;


@Service
public class LoginServiceImpl implements LoginService{

	@Autowired
	LoginDao logDao;
	
	
	public LoginDao getLogDao() {
		return logDao;
	}


	public void setLogDao(LoginDao logDao) {
		this.logDao = logDao;
	}


	@Override
	public Login getUserById(String unm) {
		
		return logDao.getUserById(unm);
	}


	@Override
	public boolean validateUser(Login user) {
		
		Login daouser=logDao.getUserById(user.getUserName());
		if(user.getUserName().equalsIgnoreCase(daouser.getUserName()) && user.getUserPass().equalsIgnoreCase(daouser.getUserPass())) 
		{
		   return true;	
		}
		else
		{
		return false;
		}
	}


	@Override
	public RegisterDto addUserDetails(RegisterDto userDetails) {
		
		return logDao.addUserDetails(userDetails);
	}


	@Override
	public Login addUser(Login user) {
		
		return logDao.addUser(user);
	}


	@Override
	public ArrayList<RegisterDto> getAllUserDetails() {
		
		return logDao.getAllUserDetails();
	}


	@Override
	public boolean deleteUser(String unm) {
		
		
		return logDao.deleteUser(unm);
	}


	@Override
	public int updateUser(String unm) {
		
		return logDao.updateUser(unm);
	}

	
}
