package com.cg.ems.service;

import java.util.ArrayList;

import com.cg.ems.dto.Login;
import com.cg.ems.dto.RegisterDto;

public interface LoginService {

	
	public Login getUserById(String unm);
	public RegisterDto addUserDetails(RegisterDto userDetails);
	public Login addUser(Login user);
	public ArrayList<RegisterDto> getAllUserDetails();
	public boolean deleteUser(String unm);
	public int updateUser(String unm);
	
	public boolean validateUser(Login user);
	
	
}
