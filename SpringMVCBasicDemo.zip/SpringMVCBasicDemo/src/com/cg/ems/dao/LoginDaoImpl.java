package com.cg.ems.dao;

import org.springframework.stereotype.Component;

import com.cg.ems.dto.Login;

@Component
public class LoginDaoImpl implements LoginDao{

	
	
	@Override
	public Login getUserById(String unm) {
		
		Login userDetails=new Login("rohit@gmail.com","rohit");
		return userDetails;
	}

}
