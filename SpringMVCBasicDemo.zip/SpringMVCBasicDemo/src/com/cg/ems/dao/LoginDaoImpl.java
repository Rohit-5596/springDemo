package com.cg.ems.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

import com.cg.ems.dto.Login;
import com.cg.ems.dto.RegisterDto;

@Component
@Transactional
public class LoginDaoImpl implements LoginDao{

	
	@PersistenceContext
	EntityManager em;
	@Override
	public Login getUserById(String unm) {
		
	    System.out.println("in LoginDao setUserById");
	    Login user=em.find(Login.class, unm);
		return user;
	}
	@Override
	public RegisterDto addUserDetails(RegisterDto userDetails) {
		
		em.persist(userDetails);
		RegisterDto reg=em.find(RegisterDto.class, userDetails.getUname());
		return reg;
	}
	@Override
	public ArrayList<RegisterDto> getAllUserDetails() {
		
		String selectUserQry="SELECT reg FROM RegisterDto reg";
		TypedQuery<RegisterDto> tq=em.createQuery(selectUserQry,RegisterDto.class); 
		ArrayList<RegisterDto> userList=(ArrayList) tq.getResultList();
		
		return userList;
	}
	@Override
	public Login addUser(Login user) {
		
		em.persist(user);
		Login uu=em.find(Login.class, user.getUserName());
		return uu;
	}
	@Override
	public boolean deleteUser(String unm) { 
		  
	    RegisterDto rDto=em.find(RegisterDto.class,unm);  
	    em.remove(rDto);  
	    Login log=em.find(Login.class,unm);  
	    em.remove(log); 
	
	return true;
	}
	@Override
	public int updateUser(String unm) {
		
		  Query query = em.createQuery("UPDATE cg_userdetails c SET c.email = :newEmail WHERE c.user_name = :userName");
	      query.setParameter("newEmail","tomcat@gmail");
	      query.setParameter("userName", unm);
	      int row = query.executeUpdate();
		return row;
	}

}
